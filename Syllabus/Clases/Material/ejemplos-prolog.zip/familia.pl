padre(juan, amanda). % esta regla es un 'hecho' porque el cuerpo está vacío
padre(alberto, juan).
madre(sara, juan).
madre(ximena, amanda).
padre(alberto, lucia).
madre(sara, lucia).
madre(lucia, felipe).
madre(lucia, camila).
padre(juan, vicente).
madre(amanda, vicente).

progenitor(X,Y) :- padre(X,Y).
progenitor(X,Y) :- madre(X,Y).

abuelo(X,Y) :- padre(X,Z),progenitor(Z,Y).
