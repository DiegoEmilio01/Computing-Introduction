numero(0).
numero(p(X)) :- numero(X).

% suma(X,Y,Z) se satisface cuando Z es la suma de X e Y

suma(0,X,X).
suma(p(X),Y,p(Z)) :- suma(X,Y,Z).
 
